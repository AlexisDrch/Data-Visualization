
// get the data
links =  [
  {
    "source": "Green Bay Packers",
    "target": "Kansas City Chiefs",
    "value": 0
  },
  {
    "source": "Green Bay Packers",
    "target": "Oakland Raiders",
    "value": 0
  },
  {
    "source": "New York Jets",
    "target": "Baltimore Colts",
    "value": 1
  },
  {
    "source": "Kansas City Chiefs",
    "target": "Minnesota Vikings",
    "value": 1
  },
  {
    "source": "Baltimore Colts",
    "target": "Dallas Cowboys",
    "value": 1
  },
  {
    "source": "Dallas Cowboys",
    "target": "Miami Dolphins",
    "value": 0
  },
  {
    "source": "Miami Dolphins",
    "target": "Washington Redskins",
    "value": 1
  },
  {
    "source": "Miami Dolphins",
    "target": "Minnesota Vikings",
    "value": 1
  },
  {
    "source": "Pittsburgh Steelers",
    "target": "Minnesota Vikings",
    "value": 1
  },
  {
    "source": "Pittsburgh Steelers",
    "target": "Dallas Cowboys",
    "value": 1
  },
  {
    "source": "Oakland Raiders",
    "target": "Minnesota Vikings",
    "value": 1
  },
  {
    "source": "Dallas Cowboys",
    "target": "Denver Broncos",
    "value": 0
  },
  {
    "source": "Pittsburgh Steelers",
    "target": "Los Angeles Rams",
    "value": 1
  },
  {
    "source": "Oakland Raiders",
    "target": "Philadelphia Eagles",
    "value": 1
  },
  {
    "source": "San Francisco 49ers",
    "target": "Cincinnati Bengals",
    "value": 0
  },
  {
    "source": "Washington Redskins",
    "target": "Miami Dolphins",
    "value": 0
  },
  {
    "source": "Los Angeles Raiders",
    "target": "Washington Redskins",
    "value": 1
  },
  {
    "source": "San Francisco 49ers",
    "target": "Miami Dolphins",
    "value": 0
  },
  {
    "source": "Chicago Bears",
    "target": "New England Patriots",
    "value": 0
  },
  {
    "source": "New York Giants",
    "target": "Denver Broncos",
    "value": 0
  },
  {
    "source": "Washington Redskins",
    "target": "Denver Broncos",
    "value": 0
  },
  {
    "source": "San Francisco 49ers",
    "target": "Denver Broncos",
    "value": 0
  },
  {
    "source": "New York Giants",
    "target": "Buffalo Bills",
    "value": 0
  },
  {
    "source": "Washington Redskins",
    "target": "Buffalo Bills",
    "value": 0
  },
  {
    "source": "Dallas Cowboys",
    "target": "Buffalo Bills",
    "value": 0
  },
  {
    "source": "San Francisco 49ers",
    "target": "San Diego Chargers",
    "value": 0
  },
  {
    "source": "Dallas Cowboys",
    "target": "Pittsburgh Steelers",
    "value": 0
  },
  {
    "source": "Green Bay Packers",
    "target": "New England Patriots",
    "value": 0
  },
  {
    "source": "Denver Broncos",
    "target": "Green Bay Packers",
    "value": 1
  },
  {
    "source": "Denver Broncos",
    "target": "Atlanta Falcons",
    "value": 1
  },
  {
    "source": "St. Louis Rams",
    "target": "Tennessee Titans",
    "value": 0
  },
  {
    "source": "Baltimore Ravens",
    "target": "New York Giants",
    "value": 1
  },
  {
    "source": "New England Patriots",
    "target": "St. Louis Rams",
    "value": 1
  },
  {
    "source": "Tampa Bay Buccaneers",
    "target": "Oakland Raiders",
    "value": 0
  },
  {
    "source": "New England Patriots",
    "target": "Carolina Panthers",
    "value": 1
  },
  {
    "source": "New England Patriots",
    "target": "Philadelphia Eagles",
    "value": 1
  },
  {
    "source": "Pittsburgh Steelers",
    "target": "Seattle Seahawks",
    "value": 1
  },
  {
    "source": "Indianapolis Colts",
    "target": "Chicago Bears",
    "value": 1
  },
  {
    "source": "New York Giants",
    "target": "New England Patriots",
    "value": 0
  },
  {
    "source": "Pittsburgh Steelers",
    "target": "Arizona Cardinals",
    "value": 1
  },
  {
    "source": "New Orleans Saints",
    "target": "Indianapolis Colts",
    "value": 0
  },
  {
    "source": "Green Bay Packers",
    "target": "Pittsburgh Steelers",
    "value": 0
  },
  {
    "source": "Baltimore Ravens",
    "target": "San Francisco 49ers",
    "value": 1
  },
  {
    "source": "Seattle Seahawks",
    "target": "Denver Broncos",
    "value": 0
  },
  {
    "source": "New England Patriots",
    "target": "Seattle Seahawks",
    "value": 1
  },
  {
    "source": "Denver Broncos",
    "target": "Carolina Panthers",
    "value": 1
  },
  {
    "source": "New England Patriots",
    "target": "Atlanta Falcons",
    "value": 1
  },
  {
    "source": "Philadelphia Eagles",
    "target": "New England Patriots",
    "value": 0
  }
];